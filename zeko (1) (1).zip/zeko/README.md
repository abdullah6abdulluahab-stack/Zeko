# Zeko (زیکۆ)

Your own AI that floats on top of TikTok. Tap the Z bubble, talk, and it answers out loud in the voice and humor you picked. If screen sharing is on, it sees the video you're watching and reacts to it.

Android only (Android 8+). iOS doesn't allow apps to float over other apps.

## Build the APK

1. Install Android Studio on a computer.
2. Unzip this folder, then in Android Studio choose **Open** and select the `zeko` folder. Let it sync (it downloads what it needs).
3. Plug in your phone (USB debugging on) and press **Run**, or choose **Build > Build APK(s)** and send the APK to your phone.
4. On the phone, allow installing from the source you used.

## Set it up

1. Get an API key at console.anthropic.com (pay-as-you-go; separate from the Claude app plan).
2. Open Zeko, paste the key, pick a humor and a voice, press **Test voice**.
3. Press **Start Zeko** and accept the prompts: display over other apps, microphone, notifications, and screen sharing.
4. Open TikTok. Tap the Z to talk.

## Using it

- Tap the Z: it listens. Tap again to finish early.
- Tap while it's thinking or talking: it stops.
- Hold the Z: opens settings (change voice or humor any time).
- Drag the Z anywhere.
- Zeko asks TikTok to pause or go quiet while you talk, so the mic hears you. Whether TikTok listens to that is up to TikTok.

## Privacy

- The API key is stored only on the phone.
- A screenshot is sent only when you ask Zeko something, and only the latest frame. It's whatever is on screen at that moment, so don't ask with private chats open. Turn off "Let Zeko see my screen" to stop it entirely.

## Files

- `ZekoService.kt`: the floating bubble, listening, speaking
- `Brain.kt`: the AI call
- `Persona.kt`: who Zeko is and the humor modes (edit these to change its personality)
- `ScreenPeek.kt`: screen capture
- `MainActivity.kt`: settings screen
