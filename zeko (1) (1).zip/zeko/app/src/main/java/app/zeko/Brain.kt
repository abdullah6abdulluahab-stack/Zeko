package app.zeko

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** The thinking part: one call to the Anthropic Messages API. Run on a background thread. */
object Brain {

    class Turn(val role: String, val text: String)

    fun ask(
        apiKey: String,
        model: String,
        system: String,
        history: List<Turn>,
        userText: String,
        imageJpegBase64: String?,
        webSearch: Boolean,
    ): String {
        val messages = JSONArray()
        for (t in history) {
            messages.put(JSONObject().put("role", t.role).put("content", t.text))
        }

        val content = JSONArray()
        if (imageJpegBase64 != null) {
            content.put(
                JSONObject()
                    .put("type", "image")
                    .put(
                        "source",
                        JSONObject()
                            .put("type", "base64")
                            .put("media_type", "image/jpeg")
                            .put("data", imageJpegBase64)
                    )
            )
        }
        content.put(JSONObject().put("type", "text").put("text", userText))
        messages.put(JSONObject().put("role", "user").put("content", content))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 400)
            .put("system", system)
            .put("messages", messages)
        if (webSearch) {
            body.put(
                "tools",
                JSONArray().put(
                    JSONObject()
                        .put("type", "web_search_20250305")
                        .put("name", "web_search")
                        .put("max_uses", 2)
                )
            )
        }

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                val msg = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (e: Exception) {
                    text.take(160)
                }
                throw RuntimeException("API $code: $msg")
            }

            val blocks = JSONObject(text).getJSONArray("content")
            val out = StringBuilder()
            for (i in 0 until blocks.length()) {
                val b = blocks.getJSONObject(i)
                if (b.optString("type") == "text") out.append(b.getString("text"))
            }
            return out.toString().trim()
        } finally {
            conn.disconnect()
        }
    }
}
