package app.zeko

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

enum class Mode(val color: Int) {
    IDLE(0xFFC6FF3D.toInt()),      // acid lime
    LISTENING(0xFF36E0FF.toInt()), // cyan
    THINKING(0xFFFFB020.toInt()),  // amber
    SPEAKING(0xFFFF3D9A.toInt()),  // hot pink
}

/** The floating "Z" that sits on top of TikTok. Its ring color and pulse show what Zeko is doing. */
class Bubble(ctx: Context) : View(ctx) {

    var mode: Mode = Mode.IDLE
        set(v) {
            field = v
            invalidate()
        }

    private var phase = 0f
    private val d = resources.displayMetrics.density

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF14141C.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pulse = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1100
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            if (mode != Mode.IDLE) invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (64 * d).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = 24 * d

        if (mode != Mode.IDLE) {
            pulse.color = mode.color
            pulse.alpha = ((1f - phase) * 150).toInt()
            pulse.strokeWidth = 3 * d
            c.drawCircle(cx, cy, r + phase * 7 * d, pulse)
        }
        c.drawCircle(cx, cy, r, fill)
        ring.color = mode.color
        ring.strokeWidth = 3.5f * d
        c.drawCircle(cx, cy, r, ring)
        letter.textSize = 24 * d
        c.drawText("Z", cx, cy + 8 * d, letter)
    }
}
