package app.zeko

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Settings screen: pick the voice, the humor, plug in the key, and switch Zeko on. */
class MainActivity : Activity() {

    private val REQ_OVERLAY = 10
    private val REQ_PERMS = 11
    private val REQ_PROJECTION = 12
    private val ACCENT = 0xFFC6FF3D.toInt()
    private val BG = 0xFF0B0B10.toInt()
    private val MUTED = 0xFF8A8A99.toInt()

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var voices: List<Voice> = emptyList()

    private lateinit var keyEdit: EditText
    private lateinit var customEdit: EditText
    private lateinit var langEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var voiceSpinner: Spinner
    private lateinit var startBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(64))
        }
        scroll.addView(col)
        setContentView(scroll)

        // ---- header
        col.addView(text("ZEKO", 34f, ACCENT, bold = true))
        col.addView(text("زیکۆ", 18f, MUTED))
        col.addView(text("Your own AI that rides on top of TikTok.", 14f, Color.WHITE).apply { setPadding(0, dp(8), 0, dp(4)) })

        // ---- key
        col.addView(section("Brain"))
        keyEdit = edit("Anthropic API key (sk-ant-…)", prefs.apiKey, password = true)
        col.addView(keyEdit)
        col.addView(text("Get one at console.anthropic.com. It's pay-as-you-go and separate from the Claude app plan. Stored only on this phone.", 12f, MUTED))
        modelEdit = edit("Model", prefs.model)
        col.addView(modelEdit)

        // ---- humor
        col.addView(section("Humor"))
        val rg = RadioGroup(this)
        Persona.humors.forEachIndexed { i, h ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i
                text = "${h.label}  ·  ${h.blurb}"
                setTextColor(Color.WHITE)
                isChecked = h.id == prefs.humor
            })
        }
        rg.setOnCheckedChangeListener { _, id ->
            Persona.humors.getOrNull(id - 100)?.let { prefs.humor = it.id }
        }
        col.addView(rg)
        customEdit = edit("Extra personality notes (optional)", prefs.custom, multiline = true)
        col.addView(customEdit)

        // ---- voice
        col.addView(section("Voice"))
        voiceSpinner = Spinner(this)
        col.addView(voiceSpinner)
        col.addView(text("Pitch", 12f, MUTED))
        col.addView(slider((prefs.pitch - 0.5f) / 1.5f) { prefs.pitch = 0.5f + it * 1.5f })
        col.addView(text("Speed", 12f, MUTED))
        col.addView(slider((prefs.rate - 0.6f) / 1.2f) { prefs.rate = 0.6f + it * 1.2f })
        col.addView(button("Test voice", outlined = true) { testVoice() })
        langEdit = edit("Language code (en-US, en-GB…)", prefs.lang)
        col.addView(langEdit)

        // ---- kurdish
        col.addView(section("Kurdish"))
        col.addView(toggle("Kurdish mode", "Understands and answers in Sorani or Kurmanji, and knows Kurdistan's history, religions and politics. To talk to it in Kurdish, set the language code above to ckb-IQ (Sorani) or ku (Kurmanji). Your phone's speech engine has to support it, and your phone may not have a Kurdish voice to read replies aloud.", prefs.kurdish) { prefs.kurdish = it })

        // ---- senses
        col.addView(section("Senses"))
        col.addView(toggle("Let Zeko see my screen", "Sends one screenshot with each question so it can react to the video you're on.", prefs.peek) { prefs.peek = it })
        col.addView(toggle("Check trends online", "Lets it search the web for fresh trends. Needs web search enabled on your API account.", prefs.web) { prefs.web = it })

        // ---- go
        startBtn = button("Start Zeko", outlined = false) { onStartClicked() }
        col.addView(startBtn.apply { (layoutParams as? LinearLayout.LayoutParams)?.topMargin = dp(24) })
        col.addView(
            text(
                "Tap the Z to talk, tap again when you're done. Tap while it's talking to shut it up. " +
                    "Hold the Z to open this screen. Drag it anywhere. Change the screen-sharing switch, then stop and start Zeko again.",
                12f, MUTED
            ).apply { setPadding(0, dp(12), 0, 0) }
        )

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) runOnUiThread { loadVoices() }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        saveAll()
        super.onPause()
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ small UI helpers

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }

    private fun section(s: String) = text(s.uppercase(), 12f, ACCENT, bold = true).apply {
        setPadding(0, dp(28), 0, dp(6))
        letterSpacing = 0.15f
    }

    private fun edit(hint: String, value: String, password: Boolean = false, multiline: Boolean = false) =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(Color.WHITE)
            setHintTextColor(MUTED)
            textSize = 14f
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multiline) minLines = 2
        }

    private fun button(label: String, outlined: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(if (outlined) ACCENT else Color.BLACK)
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            if (outlined) setStroke(dp(2), ACCENT) else setColor(ACCENT)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) }
    }

    private fun slider(initial: Float, onChange: (Float) -> Unit) = SeekBar(this).apply {
        max = 100
        progress = (initial.coerceIn(0f, 1f) * 100).toInt()
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p / 100f)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun toggle(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val sw = Switch(this).apply {
            text = title
            setTextColor(Color.WHITE)
            isChecked = on
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        box.addView(sw)
        box.addView(text(sub, 12f, MUTED))
        return box
    }

    // ------------------------------------------------------------ voices

    private fun loadVoices() {
        val t = tts ?: return
        val lang = Locale.forLanguageTag(prefs.lang).language
        voices = (t.voices ?: emptySet())
            .filter { it.locale.language == lang && it.features?.contains("notInstalled") != true }
            .sortedBy { it.name }
        val labels = voices.mapIndexed { i, v ->
            val where = v.locale.displayCountry.ifEmpty { v.locale.displayLanguage }
            val q = if (v.quality >= Voice.QUALITY_HIGH) "HD" else "standard"
            val net = if (v.isNetworkConnectionRequired) " · online" else ""
            "Voice ${i + 1} · $where · $q$net"
        }.ifEmpty { listOf("Default voice") }

        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val saved = voices.indexOfFirst { it.name == prefs.voice }
        if (saved >= 0) voiceSpinner.setSelection(saved)
        voiceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                voices.getOrNull(pos)?.let { prefs.voice = it.name }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun testVoice() {
        val t = tts ?: return
        t.setLanguage(Locale.forLanguageTag(langEdit.text.toString().ifBlank { "en-US" }))
        voices.getOrNull(voiceSpinner.selectedItemPosition)?.let { t.setVoice(it) }
        t.setPitch(prefs.pitch)
        t.setSpeechRate(prefs.rate)
        t.speak("Yo, it's Zeko. This is what I sound like.", TextToSpeech.QUEUE_FLUSH, null, "test")
    }

    // ------------------------------------------------------------ start / stop flow

    private fun saveAll() {
        if (!::keyEdit.isInitialized) return
        prefs.apiKey = keyEdit.text.toString()
        prefs.model = modelEdit.text.toString()
        prefs.custom = customEdit.text.toString()
        prefs.lang = langEdit.text.toString()
    }

    private fun refresh() {
        if (!::startBtn.isInitialized) return
        startBtn.text = if (ZekoService.running) "Stop Zeko" else "Start Zeko"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    /** Walks through each permission in turn, then launches the service. */
    private fun onStartClicked() {
        saveAll()
        if (ZekoService.running) {
            startService(Intent(this, ZekoService::class.java).setAction(ZekoService.ACTION_STOP))
            main.postDelayed({ refresh() }, 400)
            return
        }
        if (prefs.apiKey.isEmpty()) {
            toast("Add your API key first.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Turn on \"Display over other apps\" for Zeko, then come back.")
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQ_OVERLAY
            )
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), REQ_PERMS)
            return
        }
        if (prefs.peek) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
            return
        }
        launch(null, 0)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> if (Settings.canDrawOverlays(this)) onStartClicked()
            else toast("Zeko can't float over TikTok without that permission.")

            REQ_PROJECTION -> if (resultCode == RESULT_OK && data != null) {
                launch(data, resultCode)
            } else {
                toast("Screen sharing was declined, so Zeko will start without seeing your screen.")
                launch(null, 0)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        val micIdx = permissions.indexOf(Manifest.permission.RECORD_AUDIO)
        val micDenied = micIdx >= 0 && grantResults.getOrNull(micIdx) != PackageManager.PERMISSION_GRANTED
        if (micDenied) toast("Zeko needs the microphone to hear you.") else onStartClicked()
    }

    private fun launch(projectionData: Intent?, code: Int) {
        val i = Intent(this, ZekoService::class.java)
        if (projectionData != null) {
            i.putExtra(ZekoService.EXTRA_CODE, code)
            i.putExtra(ZekoService.EXTRA_DATA, projectionData)
        }
        startForegroundService(i)
        toast("Zeko's bubble is up. Open TikTok.")
        main.postDelayed({ refresh() }, 600)
        moveTaskToBack(true)
    }
}
