package app.zeko

import android.content.Context

/** Everything the user can change, stored privately on the phone. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zeko", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    var humor: String
        get() = sp.getString("humor", "chaotic") ?: "chaotic"
        set(v) = sp.edit().putString("humor", v).apply()

    var custom: String
        get() = sp.getString("custom", "") ?: ""
        set(v) = sp.edit().putString("custom", v.trim()).apply()

    var voice: String
        get() = sp.getString("voice", "") ?: ""
        set(v) = sp.edit().putString("voice", v).apply()

    var lang: String
        get() = sp.getString("lang", "en-US") ?: "en-US"
        set(v) = sp.edit().putString("lang", v.trim().ifEmpty { "en-US" }).apply()

    var pitch: Float
        get() = sp.getFloat("pitch", 1.0f)
        set(v) = sp.edit().putFloat("pitch", v).apply()

    var rate: Float
        get() = sp.getFloat("rate", 1.05f)
        set(v) = sp.edit().putFloat("rate", v).apply()

    /** Send a screenshot of what's on screen along with each question. */
    var peek: Boolean
        get() = sp.getBoolean("peek", true)
        set(v) = sp.edit().putBoolean("peek", v).apply()

    /** Let the AI search the web for fresh trends (must be enabled on your API account). */
    var web: Boolean
        get() = sp.getBoolean("web", false)
        set(v) = sp.edit().putBoolean("web", v).apply()

    /** Kurdish language + Kurdistan history, religions and politics briefing. */
    var kurdish: Boolean
        get() = sp.getBoolean("kurdish", false)
        set(v) = sp.edit().putBoolean("kurdish", v).apply()

    companion object {
        const val DEFAULT_MODEL = "claude-haiku-5-5"
    }
}
