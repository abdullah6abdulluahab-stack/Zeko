package app.zeko

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Base64
import java.io.ByteArrayOutputStream

/**
 * Keeps the most recent frame of the screen so Zeko can "see" what you're watching.
 * Only one frame is held in memory, and a frame only leaves the phone when you ask Zeko a question.
 * (Android allows one virtual display per screen-capture permission, so it stays open while Zeko runs.)
 */
class ScreenPeek(ctx: Context, projection: MediaProjection) {

    private val thread = HandlerThread("zeko-peek").apply { start() }
    private val handler = Handler(thread.looper)
    private val lock = Any()
    private var latest: Image? = null
    private val reader: ImageReader
    private val display: VirtualDisplay

    init {
        val dm = ctx.resources.displayMetrics
        val w = (dm.widthPixels / 2).coerceAtLeast(2)
        val h = (dm.heightPixels / 2).coerceAtLeast(2)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r ->
            val img = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (img != null) {
                synchronized(lock) {
                    latest?.close()
                    latest = img
                }
            }
        }, handler)
        display = projection.createVirtualDisplay(
            "zeko-peek", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
    }

    /** Latest frame as a base64 JPEG, or null if nothing has been captured yet. */
    fun snapshotJpegBase64(): String? {
        return synchronized(lock) {
            val img = latest ?: return@synchronized null
            val plane = img.planes[0]
            plane.buffer.rewind()
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val wide = Bitmap.createBitmap(
                img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            wide.copyPixelsFromBuffer(plane.buffer)
            val cropped = Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
            val out = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 70, out)
            wide.recycle()
            cropped.recycle()
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }
    }

    fun release() {
        try {
            display.release()
        } catch (e: Exception) {
        }
        synchronized(lock) {
            latest?.close()
            latest = null
        }
        try {
            reader.close()
        } catch (e: Exception) {
        }
        thread.quitSafely()
    }
}
