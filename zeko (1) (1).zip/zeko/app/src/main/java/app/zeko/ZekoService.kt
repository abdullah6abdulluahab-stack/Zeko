package app.zeko

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * The always-on part. Draws the floating Z bubble over other apps, listens when you tap it,
 * asks the AI, and talks back in the voice and humor you picked.
 *
 * Tap: talk / finish talking.  Tap while it's thinking or speaking: shut it up.
 * Hold: open settings.  Drag: move it.
 */
class ZekoService : Service() {

    companion object {
        const val ACTION_STOP = "app.zeko.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        @Volatile
        var running = false
    }

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: Bubble
    private lateinit var caption: TextView
    private lateinit var lp: WindowManager.LayoutParams

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var projection: MediaProjection? = null
    private var peek: ScreenPeek? = null
    private var focusReq: AudioFocusRequest? = null

    private val history = ArrayList<Brain.Turn>()
    private var mode = Mode.IDLE
    private var reqId = 0
    private var uttCount = 0
    private var currentUtt = ""
    private var hideCaption: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        prefs = Prefs(this)
        audio = getSystemService(AudioManager::class.java)
        wm = getSystemService(WindowManager::class.java)

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = readProjectionData(intent)
        val wantPeek = data != null && code == Activity.RESULT_OK

        startAsForeground(wantPeek)
        running = true

        buildOverlay()

        if (wantPeek) {
            try {
                val mpm = getSystemService(MediaProjectionManager::class.java)
                val p = mpm.getMediaProjection(code, data!!)
                // Android 14+ wants a callback registered before the virtual display is made.
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        main.post {
                            peek?.release()
                            peek = null
                        }
                    }
                }, main)
                projection = p
                peek = ScreenPeek(this, p)
            } catch (e: Exception) {
                say("Screen peek failed: ${e.message}")
            }
        }

        initTts()
        initRecognizer()
        say("Zeko is on. Tap the Z to talk.", 3000)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readProjectionData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i?.getParcelableExtra(EXTRA_DATA)

    @Suppress("DEPRECATION")
    private fun startAsForeground(withProjection: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("zeko", "Zeko", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, ZekoService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "zeko")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zeko is on")
            .setContentText("Tap the Z bubble to talk")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(1, n, type)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------------------------------------------------------- overlay

    private fun buildOverlay() {
        val d = resources.displayMetrics.density

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
        }
        bubble = Bubble(this)
        caption = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(0xEE14141C.toInt())
                cornerRadius = 14 * d
            }
            maxWidth = (230 * d).toInt()
            visibility = View.GONE
        }
        root.addView(bubble)
        root.addView(caption)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (220 * d).toInt()
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var downT = 0L
        var dragging = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    downT = SystemClock.uptimeMillis()
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > 12 * d || abs(dy) > 12 * d)) dragging = true
                    if (dragging) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) clamp()
                    else if (SystemClock.uptimeMillis() - downT > 600) onLongPress()
                    else onTap()
                    true
                }
                else -> false
            }
        }
        wm.addView(root, lp)
    }

    /** Keep the bubble (and its caption) fully on screen. */
    private fun clamp() {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, (dm.widthPixels - root.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (dm.heightPixels - root.height).coerceAtLeast(0))
        try {
            wm.updateViewLayout(root, lp)
        } catch (e: Exception) {
        }
    }

    private fun setMode(m: Mode) {
        mode = m
        bubble.mode = m
    }

    private fun showCaption(text: String, hideAfterMs: Long = 0) {
        hideCaption?.let { main.removeCallbacks(it) }
        caption.text = text
        caption.visibility = View.VISIBLE
        root.post { clamp() }
        if (hideAfterMs > 0) {
            val r = Runnable { caption.visibility = View.GONE; root.post { clamp() } }
            hideCaption = r
            main.postDelayed(r, hideAfterMs)
        }
    }

    private fun say(text: String, ms: Long = 6000) = showCaption(text, ms)

    // ---------------------------------------------------------------- taps

    private fun onTap() {
        when (mode) {
            Mode.IDLE -> startListening()
            Mode.LISTENING -> recognizer?.stopListening()
            Mode.THINKING -> {
                reqId++
                setMode(Mode.IDLE)
                abandonFocus()
                say("Cancelled", 1500)
            }
            Mode.SPEAKING -> {
                stopSpeaking()
                setMode(Mode.IDLE)
                abandonFocus()
                caption.visibility = View.GONE
                root.post { clamp() }
            }
        }
    }

    private fun onLongPress() {
        startActivity(
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ---------------------------------------------------------------- listening

    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("This phone has no speech recognizer installed.", 8000)
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
    }

    private fun startListening() {
        val r = recognizer ?: run {
            say("Speech recognition isn't available.", 4000)
            return
        }
        stopSpeaking()
        // Ask other audio (TikTok) to pause or go quiet so the mic hears you, not the video.
        requestFocus(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        setMode(Mode.LISTENING)
        showCaption("Listening…")
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank() && mode == Mode.LISTENING) showCaption(t)
        }

        override fun onResults(results: Bundle?) {
            val t = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) {
                setMode(Mode.IDLE)
                abandonFocus()
                say("Didn't catch that.", 2500)
            } else {
                handleUtterance(t)
            }
        }

        override fun onError(error: Int) {
            setMode(Mode.IDLE)
            abandonFocus()
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Zeko needs the microphone permission."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs internet."
                else -> "Mic error ($error)."
            }
            say(msg, 3500)
        }
    }

    // ---------------------------------------------------------------- thinking

    private fun handleUtterance(text: String) {
        if (prefs.apiKey.isEmpty()) {
            setMode(Mode.IDLE)
            abandonFocus()
            say("Add your API key in the Zeko app first.", 6000)
            return
        }
        setMode(Mode.THINKING)
        showCaption("…")

        val id = ++reqId
        val key = prefs.apiKey
        val model = prefs.model
        val system = Persona.system(prefs.humor, prefs.custom, prefs.kurdish)
        val web = prefs.web
        val past = ArrayList(history)
        val screen = peek

        io.execute {
            try {
                val img = screen?.snapshotJpegBase64()
                val reply = Brain.ask(key, model, system, past, text, img, web)
                main.post {
                    if (id != reqId) return@post
                    val clean = Persona.cleanForSpeech(reply)
                    if (clean.isEmpty()) {
                        setMode(Mode.IDLE)
                        abandonFocus()
                        say("Zeko had nothing to say.", 3000)
                        return@post
                    }
                    history.add(Brain.Turn("user", text))
                    history.add(Brain.Turn("assistant", clean))
                    while (history.size > 12) {
                        history.removeAt(0)
                        history.removeAt(0)
                    }
                    speak(clean)
                }
            } catch (e: Exception) {
                main.post {
                    if (id != reqId) return@post
                    setMode(Mode.IDLE)
                    abandonFocus()
                    say(e.message ?: "Something broke.", 8000)
                }
            }
        }
    }

    // ---------------------------------------------------------------- speaking

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) setMode(Mode.SPEAKING) }
                    }

                    override fun onDone(utteranceId: String?) {
                        main.post { speakEnded(utteranceId) }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { speakEnded(utteranceId) }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        main.post { speakEnded(utteranceId) }
                    }
                })
            } else {
                say("This phone has no text-to-speech engine.", 8000)
            }
        }
    }

    /** Apply the voice, pitch and speed from settings (read fresh each time, so changes are instant). */
    private fun applyVoice() {
        val t = tts ?: return
        t.setLanguage(Locale.forLanguageTag(prefs.lang))
        val name = prefs.voice
        if (name.isNotEmpty()) {
            t.voices?.firstOrNull { it.name == name }?.let { t.setVoice(it) }
        }
        t.setPitch(prefs.pitch)
        t.setSpeechRate(prefs.rate)
    }

    private fun speak(text: String) {
        showCaption(text)
        if (!ttsReady) {
            setMode(Mode.IDLE)
            abandonFocus()
            return
        }
        applyVoice()
        requestFocus(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        currentUtt = "u${++uttCount}"
        setMode(Mode.SPEAKING)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, currentUtt)
    }

    private fun speakEnded(id: String?) {
        if (id != currentUtt || mode != Mode.SPEAKING) return
        setMode(Mode.IDLE)
        abandonFocus()
        showCaption(caption.text.toString(), 3000)
    }

    private fun stopSpeaking() {
        currentUtt = ""
        tts?.stop()
    }

    // ---------------------------------------------------------------- audio focus

    private fun requestFocus(type: Int) {
        abandonFocus()
        val req = AudioFocusRequest.Builder(type)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setOnAudioFocusChangeListener { _ -> }
            .build()
        audio.requestAudioFocus(req)
        focusReq = req
    }

    private fun abandonFocus() {
        focusReq?.let { audio.abandonAudioFocusRequest(it) }
        focusReq = null
    }

    // ---------------------------------------------------------------- cleanup

    override fun onDestroy() {
        running = false
        reqId++
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
        tts?.stop()
        tts?.shutdown()
        recognizer?.destroy()
        peek?.release()
        projection?.stop()
        abandonFocus()
        io.shutdownNow()
        super.onDestroy()
    }
}
